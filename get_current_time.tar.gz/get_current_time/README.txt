INSTRUCTIONS
-----------

1. For updating timezone configuration Please Refer - /admin/config/get_current_time/adminsettings [Configuration/System menu]
2. Place Block inside Structure Block Layout - Block Name [Timezone block]