<?php

namespace Drupal\get_current_time\Services;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Class TimeZoneService.
 */
class TimeZoneService {
  private $config;

  public function __construct(ConfigFactoryInterface $config) {
    $this->config = $config;
  }

  public function getServiceData () {
    $timezone = $this->config
    ->get('get_current_time.adminsettings')
    ->get('get_current_time_timezone');
    $show_time = '';
    if($timezone){
      date_default_timezone_set($timezone);
      $show_time = date('jS M Y - h:i A') ;
    }
    return $show_time;
  }
  
}