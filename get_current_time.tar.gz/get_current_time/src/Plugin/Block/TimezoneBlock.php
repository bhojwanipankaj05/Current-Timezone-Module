<?php

namespace Drupal\get_current_time\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Provides a block with render timezone.
 *
 * @Block(
 *   id = "current_timezone_block",
 *   admin_label = @Translation("Timezone block"),
 * )
 */
class TimezoneBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
    $service = \Drupal::service('get_current_time.current_time_zone');
    $config = \Drupal::config('get_current_time.adminsettings');
    $country = $config->get('get_current_time_country');
    $city = $config->get('get_current_time_city');
    return array(
            '#theme' => 'timezone_blk',
            '#time' => $service->getServiceData(),
            '#country' => $country,
            '#city' => $city
        );
  }

  public function getCacheMaxAge() {
    return 0;
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['timezone_block_settings'] = $form_state->getValue('timezone_block_settings');
  }
}

