<?php  
/**  
 * @file  
 * Contains Drupal\get_current_time\Form\ConfigurationForm.  
 */  
namespace Drupal\get_current_time\Form;  
use Drupal\Core\Form\ConfigFormBase;  
use Drupal\Core\Form\FormStateInterface;  
  
class ConfigurationForm extends ConfigFormBase {  
  /**  
   * {@inheritdoc}  
   */  
  protected function getEditableConfigNames() {  
    return [  
      'get_current_time.adminsettings',  
    ];  
  }  
  
  /**  
   * {@inheritdoc}  
   */  
  public function getFormId() {  
    return 'get_current_time_form';  
  }  

  /**  
   * {@inheritdoc}  
   */  
  public function buildForm(array $form, FormStateInterface $form_state) {  
    $config = $this->config('get_current_time.adminsettings');  
  
    $form['get_current_time_country'] = [  
      '#type' => 'textfield',  
      '#title' => $this->t('Country'),  
      '#default_value' => $config->get('get_current_time_country'),  
    ];  

    $form['get_current_time_city'] = [  
      '#type' => 'textfield',  
      '#title' => $this->t('City'),  
      '#default_value' => $config->get('get_current_time_city'),  
    ];  

    $timezones = array('' => '-- Select an Option --','America/Chicago' => 'America/Chicago', 'America/New_York' => 'America/New_York', 'Asia/Tokyo' => 'Asia/Tokyo', 'Asia/Dubai' => 'Asia/Dubai', 'Asia/Kolkata' => 'Asia/Kolkata', 'Europe/Amsterdam' => 'Europe/Amsterdam', 'Europe/Oslo' => 'Europe/Oslo', 'Europe/London' => 'Europe/London');
    $form['get_current_time_timezone'] = [  
      '#type' => 'select',  
      '#title' => $this->t('TimeZone'),  
      '#options' => $timezones,  
      '#default_value' => $config->get('get_current_time_timezone'),  
    ];  
  
    return parent::buildForm($form, $form_state);  
  }

  /**  
   * {@inheritdoc}  
   */  
  public function submitForm(array &$form, FormStateInterface $form_state) {  
    parent::submitForm($form, $form_state);  
    $this->config('get_current_time.adminsettings')  
      ->set('get_current_time_country', $form_state->getValue('get_current_time_country'))  
      ->set('get_current_time_city', $form_state->getValue('get_current_time_city'))  
      ->set('get_current_time_timezone', $form_state->getValue('get_current_time_timezone'))  
      ->save();
  }    
}  